from .core import EmployeeLocation
